const express = require('express');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const app = express();
const PORT = 8080;

app.use(cors());
app.use(bodyParser.json());

// SQLite DB 연결
const db = new sqlite3.Database('wat2watch.db');

// 테이블 생성
db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      password TEXT NOT NULL,
      name TEXT,
      subscribed_ott TEXT,
      favorite_genres TEXT
    )
  `);
  db.run(`
    CREATE TABLE IF NOT EXISTS ratings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      userId TEXT NOT NULL,
      contentId TEXT NOT NULL,
      rating REAL NOT NULL,
      comment TEXT,
      timestamp TEXT,
      FOREIGN KEY (userId) REFERENCES users(id)
    )
  `);
});
app.get('/user/:userId/ratings', (req, res) => {
  const userId = req.params.userId;
  db.all('SELECT * FROM ratings WHERE userId = ?', [userId], (err, rows) => {
    if (err) return res.status(500).send('DB Error');
    console.log('ratings rows:', rows); // rows 값 확인!
    res.json(rows);
  });
});

app.get('/ratings/:userId/:contentId', (req, res) => {
  const { userId, contentId } = req.params;
  db.get(
    'SELECT * FROM ratings WHERE userId = ? AND contentId = ?',
    [userId, contentId],
    (err, row) => {
      console.log('[GET /ratings/:userId/:contentId]', userId, contentId, '→', row);
      if (err) return res.status(500).send('DB Error');
      if (row) res.json(row);
      else res.status(404).send('Not rated');
    }
  );
});

// 루트 접속 테스트
app.get('/', (req, res) => {
  res.send('<h2>Wat2Watch Node.js Server is Running!</h2>');
});

app.post('/register', (req, res) => {
  // snake_case, camelCase 모두 지원
  const id = req.body.id;
  const password = req.body.password;
  const name = req.body.name;
  const subscribedOtt = req.body.subscribedOtt || req.body.subscribed_ott;
  const favoriteGenres = req.body.favoriteGenres || req.body.favorite_genres;

  console.log('REQ BODY (register):', req.body);

  if (!id || !password) return res.status(400).send('Missing id or password');
  db.run(
    `INSERT INTO users (id, password, name, subscribed_ott, favorite_genres)
     VALUES (?, ?, ?, ?, ?)`,
    [
      id,
      password,
      name,
      JSON.stringify(subscribedOtt || []),
      JSON.stringify(favoriteGenres || [])
    ],
    function(err) {
      if (err) {
        if (err.code === 'SQLITE_CONSTRAINT') return res.status(409).send('ID already exists');
        return res.status(500).send('DB Error');
      }
      res.send('User registered!');
    }
  );
});

app.post('/ratings', (req, res) => {
  // 요청 본문 로그
  console.log('\n==== [POST /ratings] 요청 ====');
  console.log('REQ BODY:', req.body);

  // snake_case, camelCase 모두 지원하게끔
  const userId = req.body.userId || req.body.user_id;
  const contentId = req.body.contentId || req.body.content_id;
  const rating = Number(req.body.rating);
  const comment = req.body.comment;

  console.log('userId:', userId, '| contentId:', contentId, '| rating:', rating, '| comment:', comment);

  if (!userId || !contentId || rating == null) {
    console.error('[400] Missing parameter(s):', req.body);
    return res.status(400).send('Missing parameter(s)');
  }

  db.get(
    'SELECT id FROM ratings WHERE userId = ? AND contentId = ?',
    [userId, contentId],
    (err, row) => {
      if (err) {
        console.error('DB SELECT error:', err);
        return res.status(500).send('DB Error');
      }
      const timestamp = new Date().toISOString();
      if (row) {
        db.run(
          'UPDATE ratings SET rating = ?, comment = ?, timestamp = ? WHERE id = ?',
          [rating, comment || '', timestamp, row.id],
          function(err2) {
            if (err2) {
              console.error('DB UPDATE error:', err2);
              return res.status(500).send('DB Error');
            }
            console.log('[200] Rating updated!');
            res.send('Rating updated!');
          }
        );
      } else {
        db.run(
          'INSERT INTO ratings (userId, contentId, rating, comment, timestamp) VALUES (?, ?, ?, ?, ?)',
          [userId, contentId, rating, comment || '', timestamp],
          function(err2) {
            if (err2) {
              console.error('DB INSERT error:', err2);
              return res.status(500).send('DB Error');
            }
            console.log('[200] Rating submitted!');
            res.send('Rating submitted!');
          }
        );
      }
    }
  );
});

// 로그인 API
app.post('/login', (req, res) => {
  const { id, password } = req.body;
  db.get(
    'SELECT * FROM users WHERE id = ? AND password = ?',
    [id, password],
    (err, row) => {
      if (err) return res.status(500).send('DB Error');
      if (row) {
        res.json({
          id: row.id,
          name: row.name,
          subscribedOtt: JSON.parse(row.subscribed_ott || '[]'),
          favoriteGenres: JSON.parse(row.favorite_genres || '[]'),
        });
      } else {
        res.status(401).send('Invalid credentials');
      }
    }
  );
});

// 별점 등록/수정 API
app.post('/ratings', (req, res) => {
  const { userId, contentId, rating, comment } = req.body;
  if (!userId || !contentId || rating == null) return res.status(400).send('Missing parameter(s)');

  db.get(
    'SELECT id FROM ratings WHERE userId = ? AND contentId = ?',
    [userId, contentId],
    (err, row) => {
      if (err) return res.status(500).send('DB Error');
      const timestamp = new Date().toISOString();
      if (row) {
        db.run(
          'UPDATE ratings SET rating = ?, comment = ?, timestamp = ? WHERE id = ?',
          [rating, comment || '', timestamp, row.id],
          function(err2) {
            if (err2) return res.status(500).send('DB Error');
            res.send('Rating updated!');
          }
        );
      } else {
        db.run(
          'INSERT INTO ratings (userId, contentId, rating, comment, timestamp) VALUES (?, ?, ?, ?, ?)',
          [userId, contentId, rating, comment || '', timestamp],
          function(err2) {
            if (err2) return res.status(500).send('DB Error');
            res.send('Rating submitted!');
          }
        );
      }
    }
  );
});

app.use((req, res) => {
  res.status(404).send('Not Found');
});

// 서버 실행
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
