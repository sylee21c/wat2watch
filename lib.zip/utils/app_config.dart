class AppConfig {
  static const String tmdbApiKey = '70eacb5a78b9c9c51fabb57426c078e4';
  static const String apiBaseUrl = 'http://10.0.2.2:8080';
}
